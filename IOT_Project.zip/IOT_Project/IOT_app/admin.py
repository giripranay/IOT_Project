from django.contrib import admin
from .models import Bin1

# Register your models here.

admin.site.register(Bin1)
