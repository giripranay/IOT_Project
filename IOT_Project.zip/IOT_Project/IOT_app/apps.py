from django.apps import AppConfig


class IotAppConfig(AppConfig):
    name = 'IOT_app'
